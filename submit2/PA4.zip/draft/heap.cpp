#ifndef __HEAP_CPP
#define __HEAP_CPP
#include "heap.h"


MinHeap::MinHeap(int cap)
{

}

void MinHeap::MinHeapify(int i)
{
	
}
 
int MinHeap::parent(int i)
{

}
 
int MinHeap::left(int i)
{

}
 
int MinHeap::right(int i)
{
}
 
long MinHeap::extractMin()
{
	
}

 
long MinHeap::getMin()
{
	
}
 
void MinHeap::deleteKey(int i)
{
	
}
 
void MinHeap::insertKey(long k)
{
	
}

long* MinHeap::getHeap()
{
	
}

#endif