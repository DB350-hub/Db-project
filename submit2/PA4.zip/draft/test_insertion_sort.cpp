#include <iostream>
#include "sorts.cpp"
#include <fstream>
#include <vector>
#include <time.h>
#include <algorithm>
#include <chrono>
using namespace std;

void test(vector<long> entries){
    using namespace std::chrono;
    high_resolution_clock::time_point timeStart = high_resolution_clock::now();;
    vector<long> result = InsertionSort(entries);   
    sort(entries.begin(),entries.end());
    for(int i=0;i<entries.size();i++){
        if(entries[i] != result[i]){
            cout << "OUTPUT NOT SORTED TEST FAILED EXITING!" << endl;
            return;
        }
    }
    high_resolution_clock::time_point timeEnd = high_resolution_clock::now();;
    duration<double> totalTime = duration_cast<duration<double>>(timeEnd - timeStart);
    cout << "TEST PASSED IN : " << totalTime.count() << " SECONDS."<<endl;
}

int main(){
    vector<long> entries;
    srand(time(NULL));
    for(int i=0;i<75000;i++){
        entries.push_back(-75000 + rand()%150000);
    }
    test(entries);
    return 0;
}