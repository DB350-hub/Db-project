#include <iostream>

using namespace std;

class cuckoo
{
private:
    /* data */
    int *table1;
    int *table2;
    int hash_variable;

public:
    cuckoo(/* args */);
    ~cuckoo();
    bool search(int key);
    void insert(int key);
    void deleteK(int key);
    void print_tables();
    //any additional function will come here
};

//constructor
cuckoo::cuckoo()
{
    hash_variable = 11;
    table1 = new int[hash_variable];
    table2 = new int[hash_variable];
}

void cuckoo::insert(int key)
{
}
bool cuckoo::search(int key)
{
}
void cuckoo::deleteK(int key)
{
}

void cuckoo::print_tables()
{
}

//destructor
cuckoo::~cuckoo()
{
    delete[] table1;
    delete[] table2;
}

int main()
{
    cout << "Hello world" << endl;
}