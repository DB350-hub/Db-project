#ifndef __SORTS_CPP
#define __SORTS_CPP
#include "sorts.h"
#include "list.cpp"
#include "heap.cpp"

//=====================================================================================
vector<long> InsertionSort(vector<long> nums)
{
	
}

//=====================================================================================
vector<long> MergeSort(vector<long> nums)
{
	
}

//=====================================================================================
vector<long> HeapSort(vector<long> nums)
{
	
}

#endif